FPlotDemo

FPlotDemo is an example of an application using the FPlotLibrary to plot mathematical functions and measurement data.
To run FPlotDemo correctly you need to copy the files data.csv and test.wav to the folder where the executable
FPlotDemo.exe lies.

History:

FPlot 1.03
First version of FPlotDemo

FPlot 1.04
New feature: New Button "Load WAV" that loads a WAV-file.